package com.cts.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.dao.InternDAO;

@Controller
public class DeleteController {

	@Autowired
	private InternDAO InternDAO;

	@RequestMapping(value = "/delete/{InternId}")
	public ModelAndView deleteInternById(ModelAndView mv, @PathVariable("InternId") int InternId)
			throws IOException {

		int counter = InternDAO.delete(InternId);

		if (counter > 0) {
			mv.addObject("msg", "Intern records deleted against Intern id: " + InternId);
		} else {
			mv.addObject("msg", "Error- check the console log.");
		}

		mv.setViewName("delete");

		return mv;
	}

}