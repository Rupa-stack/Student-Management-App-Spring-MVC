package com.cts.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.dao.InternDAO;
import com.cts.model.Intern;


@Controller
public class CreateController {

	@Autowired
	private InternDAO internDAO;
	
	@RequestMapping(value="/index")
	public ModelAndView readIntern(ModelAndView model) throws IOException {

		//List<Intern> listIntern = InternDAO.create();
		//model.addObject("listIntern", listIntern);
		model.setViewName("create");

		return model;
	}

	
	  @RequestMapping(value = "/create") //, method = RequestMethod.POST) 
	  public
	  ModelAndView createIntern(@RequestParam("name") String
	  name, @RequestParam("email") String email,
	  
	  @RequestParam("domain") String domain, ModelAndView mv) {
	  
	  Intern intern = new Intern(); 
	  intern.setName(name); 
	  intern.setEmail(email);
	  intern.setDomain(domain);
	  
	  int counter = internDAO.create(intern);
	  
	  if (counter > 0) { mv.addObject("msg", "Intern registration successful."); }
	  else { mv.addObject("msg", "Error- check the console log."); }
	  
	  mv.setViewName("create");
	  
	  return mv; }
	 
}