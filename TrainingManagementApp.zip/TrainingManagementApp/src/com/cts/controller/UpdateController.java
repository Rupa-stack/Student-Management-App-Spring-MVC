package com.cts.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.dao.InternDAO;
import com.cts.model.Intern;

@Controller
public class UpdateController {

	@Autowired
	private InternDAO InternDAO;

	@RequestMapping(value = "/update/{InternId}")
	public ModelAndView findInternById(ModelAndView model, @PathVariable("InternId") int InternId)
			throws IOException {

		List<Intern> listIntern = InternDAO.findInternById(InternId);
		model.addObject("listIntern", listIntern);
		model.setViewName("update");

		return model;
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView updateIntern(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("email") String email, @RequestParam("domain") String domain, ModelAndView mv) {

		Intern Intern = new Intern();
		Intern.setId(id);
		Intern.setName(name);
		Intern.setEmail(email);
		Intern.setDomain(domain);

		int counter = InternDAO.update(Intern);

		if (counter > 0) {
			mv.addObject("msg", "Intern records updated against Intern id: " + Intern.getId());
		} else {
			mv.addObject("msg", "Error- check the console log.");
		}

		mv.setViewName("update");

		return mv;
	}
}