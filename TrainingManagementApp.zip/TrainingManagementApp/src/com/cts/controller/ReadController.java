package com.cts.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.dao.InternDAO;
import com.cts.model.Intern;

@Controller
public class ReadController {

	@Autowired
	private InternDAO InternDAO;

	@RequestMapping(value = "/read")
	public ModelAndView readIntern(ModelAndView model) throws IOException {

		List<Intern> listIntern = InternDAO.read();
		model.addObject("listIntern", listIntern);
		model.setViewName("read");

		return model;
	}
}