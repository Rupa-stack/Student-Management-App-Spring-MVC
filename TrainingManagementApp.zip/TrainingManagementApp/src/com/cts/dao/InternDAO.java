package com.cts.dao;

import java.util.List;

import com.cts.model.Intern;

public interface InternDAO {
	public int create(Intern intern);
	public List<Intern> read();
	public List<Intern> findInternById(int internId);
	public int update(Intern intern);
	public int delete(int internId);

}
