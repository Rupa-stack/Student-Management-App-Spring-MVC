package com.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.cts.model.Intern;


public class InternDAOImpl implements InternDAO {

	private JdbcTemplate jdbcTemplate;

	public InternDAOImpl(DataSource dataSoruce) {
		jdbcTemplate = new JdbcTemplate(dataSoruce);
	}

	public int create(Intern Intern) {

		String sql = "insert into Interns(intern_name,intern_email,intern_domain) values(?,?,?)";

		try {

			int counter = jdbcTemplate.update(sql,
					new Object[] { Intern.getName(), Intern.getEmail(), Intern.getDomain() });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public List<Intern> read() {
		List<Intern> InternList = jdbcTemplate.query("SELECT * FROM Interns", new RowMapper<Intern>() {

			public Intern mapRow(ResultSet rs, int rowNum) throws SQLException {
				Intern Intern = new Intern();

				Intern.setId(rs.getInt("intern_id"));
				Intern.setName(rs.getString("intern_name"));
				Intern.setEmail(rs.getString("intern_email"));
				Intern.setDomain(rs.getString("intern_domain"));

				return Intern;
			}

		});

		return InternList;
	}

	public List<Intern> findInternById(int InternId) {

		List<Intern> InternList = jdbcTemplate.query("SELECT * FROM Interns where intern_id=?",
				new Object[] { InternId }, new RowMapper<Intern>() {

					public Intern mapRow(ResultSet rs, int rowNum) throws SQLException {
						Intern Intern = new Intern();

						Intern.setId(rs.getInt("intern_id"));
						Intern.setName(rs.getString("intern_name"));
						Intern.setEmail(rs.getString("intern_email"));
						Intern.setDomain(rs.getString("intern_domain"));

						return Intern;
					}

				});

		return InternList;
	}

	public int update(Intern Intern) {
		String sql = "update  Interns set intern_name=?, intern_email=?, intern_domain=? where intern_id=?";

		try {

			int counter = jdbcTemplate.update(sql,
					new Object[] { Intern.getName(), Intern.getEmail(), Intern.getDomain(), Intern.getId() });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public int delete(int InternId) {
		String sql = "delete from Interns where intern_id=?";

		try {

			int counter = jdbcTemplate.update(sql, new Object[] { InternId });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

}